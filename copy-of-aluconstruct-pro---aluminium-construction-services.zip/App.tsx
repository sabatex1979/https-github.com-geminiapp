
import React from 'react';

// --- HELPER & ICON COMPONENTS ---

const NavLink = ({ children, onClick }: { children: React.ReactNode, onClick: () => void }) => (
  <button onClick={onClick} className="text-gray-300 hover:text-white transition-colors duration-300 font-semibold px-3 py-2 rounded-md text-sm uppercase tracking-wider">
    {children}
  </button>
);

const Section = ({ id, children, className = '', style }: { id: string, children: React.ReactNode, className?: string, style?: React.CSSProperties }) => (
  <section id={id} className={`w-full py-20 px-4 md:px-8 lg:px-16 ${className}`} style={style}>
    <div className="max-w-7xl mx-auto">
      {children}
    </div>
  </section>
);

const SectionTitle = ({ children }: { children: React.ReactNode }) => (
  <h2 className="text-4xl font-bold text-center text-white mb-12">
    {children}
    <div className="w-24 h-1 bg-cyan-400 mx-auto mt-4 rounded"></div>
  </h2>
);

const PhoneIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 mr-3 text-cyan-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" /></svg>;
const MailIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 mr-3 text-cyan-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" /></svg>;
const LocationIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 mr-3 text-cyan-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" /></svg>;
const PlayIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-white" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" clipRule="evenodd" /></svg>;


// --- PAGE SECTIONS ---

const Header = ({ scrollTo }: { scrollTo: (id: string) => void }) => (
  <header className="bg-slate-900 bg-opacity-80 backdrop-blur-sm fixed top-0 left-0 right-0 z-50 shadow-lg">
    <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="flex items-center justify-between h-20">
        <div className="flex-shrink-0">
          <span className="text-white text-2xl font-bold tracking-tight">AluConstruct Pro</span>
        </div>
        <div className="hidden md:block">
          <div className="ml-10 flex items-baseline space-x-4">
            <NavLink onClick={() => scrollTo('hero')}>Home</NavLink>
            <NavLink onClick={() => scrollTo('gallery')}>Gallery</NavLink>
            <NavLink onClick={() => scrollTo('services')}>Services</NavLink>
            <NavLink onClick={() => scrollTo('about')}>About Us</NavLink>
            <NavLink onClick={() => scrollTo('contact')}>Contact</NavLink>
          </div>
        </div>
      </div>
    </nav>
  </header>
);

const HeroSection = ({ scrollTo }: { scrollTo: (id: string) => void }) => (
  <Section id="hero" className="h-screen !py-0 flex items-center justify-center bg-cover bg-center" style={{ backgroundImage: "url('https://placehold.co/1920x1080/0f172a/e2e8f0?text=Modern+Building+Facade')" }}>
    <div className="absolute inset-0 bg-black bg-opacity-50"></div>
    <div className="text-center z-10 p-4">
      <h1 className="text-5xl md:text-7xl font-extrabold text-white drop-shadow-lg">Precision in Aluminium</h1>
      <p className="mt-4 text-xl md:text-2xl text-gray-300 drop-shadow-lg">Expert solutions for modern construction.</p>
      <button onClick={() => scrollTo('contact')} className="mt-8 px-8 py-4 bg-cyan-500 text-white font-bold text-lg rounded-lg hover:bg-cyan-400 focus:outline-none focus:ring-4 focus:ring-cyan-300 transition-all duration-300 ease-in-out transform hover:scale-105">
        Get a Free Quote
      </button>
    </div>
  </Section>
);

const GallerySection = () => {
  const photos = [
    { src: 'https://placehold.co/600x400/334155/ffffff?text=Aluminium+Windows', alt: 'Modern Aluminium Windows' },
    { src: 'https://placehold.co/600x400/334155/ffffff?text=Glass+Balcony', alt: 'Glass and Aluminium Balcony' },
    { src: 'https://placehold.co/600x400/334155/ffffff?text=Office+Partitions', alt: 'Aluminium Office Partitions' },
    { src: 'https://placehold.co/600x400/334155/ffffff?text=Sliding+Doors', alt: 'Aluminium Sliding Doors' },
    { src: 'https://placehold.co/600x400/334155/ffffff?text=Curtain+Wall', alt: 'Building with Aluminium Curtain Wall' },
    { src: 'https://placehold.co/600x400/334155/ffffff?text=Custom+Fabrication', alt: 'Custom Aluminium Fabrication' },
  ];

  return (
    <Section id="gallery" className="bg-slate-800">
      <SectionTitle>Our Work</SectionTitle>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {photos.map((photo, index) => (
          <div key={index} className="relative group overflow-hidden rounded-lg shadow-lg">
            <img src={photo.src} alt={photo.alt} className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-500" />
            <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-50 transition-all duration-500 flex items-center justify-center">
              <p className="text-white text-lg font-semibold opacity-0 group-hover:opacity-100 transition-opacity duration-500 p-4 text-center">{photo.alt}</p>
            </div>
          </div>
        ))}
      </div>
       <div className="mt-16 text-center">
          <h3 className="text-3xl font-bold text-white mb-6">Project Showcase Video</h3>
          <div className="relative max-w-4xl mx-auto aspect-video bg-slate-900 rounded-lg shadow-2xl flex items-center justify-center overflow-hidden cursor-pointer group">
              <img src="https://placehold.co/1280x720/1e293b/94a3b8?text=Project+Video+Thumbnail" alt="Video Thumbnail" className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-black bg-opacity-40 group-hover:bg-opacity-60 transition-all"></div>
              <PlayIcon />
              <p className="absolute bottom-4 right-4 text-white opacity-80">Click to Play</p>
          </div>
        </div>
    </Section>
  );
};

const ServicesSection = () => {
    const services = [
        { name: 'Aluminium Windows', description: 'Durable, stylish, and energy-efficient windows for any building.', price: 'Starting from $250/unit' },
        { name: 'Sliding Doors', description: 'Sleek and smooth sliding doors for patios and balconies.', price: 'Starting from $600/panel' },
        { name: 'Curtain Walls', description: 'Modern facade solutions for commercial and high-rise buildings.', price: 'Contact for quote' },
        { name: 'Office Partitions', description: 'Create functional and aesthetic office spaces with our partitions.', price: 'Starting from $120/sqm' },
        { name: 'Balcony Railings', description: 'Safe and elegant aluminium and glass railings.', price: 'Starting from $150/meter' },
        { name: 'Custom Fabrication', description: 'Bespoke aluminium structures tailored to your unique requirements.', price: 'Contact for quote' },
    ];
    
    return (
        <Section id="services" className="bg-slate-900">
            <SectionTitle>Services & Pricing</SectionTitle>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {services.map(service => (
                    <div key={service.name} className="bg-slate-800 p-8 rounded-lg shadow-xl hover:shadow-cyan-500/20 transform hover:-translate-y-2 transition-all duration-300">
                        <h3 className="text-2xl font-bold text-white mb-3">{service.name}</h3>
                        <p className="text-gray-400 mb-4 h-20">{service.description}</p>
                        <p className="text-cyan-400 font-semibold text-lg">{service.price}</p>
                    </div>
                ))}
            </div>
        </Section>
    );
}

const AboutSection = () => (
    <Section id="about" className="bg-slate-800">
        <SectionTitle>About AluConstruct Pro</SectionTitle>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="text-lg text-gray-300 leading-relaxed">
                <p className="mb-4">
                    With over a decade of experience in the industry, AluConstruct Pro stands as a leader in providing high-quality aluminium construction solutions. We specialize in designing, fabricating, and installing a wide range of products for both residential and commercial projects.
                </p>
                <p>
                    Our commitment to excellence is matched only by our dedication to using the finest materials and the latest technology, ensuring every project is delivered to the highest standards of quality, durability, and aesthetic appeal.
                </p>
            </div>
            <div className="space-y-8">
                <div>
                    <h3 className="text-2xl font-bold text-cyan-400 mb-2">Our Mission & Goals</h3>
                    <p className="text-gray-400">To revolutionize the construction industry with innovative and sustainable aluminium solutions, exceeding client expectations through precision engineering and unparalleled customer service.</p>
                </div>
                 <div>
                    <h3 className="text-2xl font-bold text-cyan-400 mb-2">Company Values</h3>
                    <ul className="list-disc list-inside text-gray-400 space-y-1">
                        <li><strong>Quality:</strong> Uncompromising standards in every product.</li>
                        <li><strong>Integrity:</strong> Honest and transparent business practices.</li>
                        <li><strong>Innovation:</strong> Continuously improving our techniques and designs.</li>
                        <li><strong>Safety:</strong> Prioritizing the well-being of our team and clients.</li>
                    </ul>
                </div>
                 <div>
                    <h3 className="text-2xl font-bold text-cyan-400 mb-2">Achievements</h3>
                     <p className="text-gray-400">Successfully completed over 500+ projects, from small residential renovations to large-scale commercial facades. Consistently rated 5 stars for customer satisfaction.</p>
                </div>
            </div>
        </div>
    </Section>
)

const ContactSection = () => (
    <Section id="contact" className="bg-slate-900">
        <SectionTitle>Contact Us</SectionTitle>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Left side: Details */}
            <div className="space-y-8">
                <div>
                    <h3 className="text-2xl font-bold text-white mb-4">Get In Touch</h3>
                    <div className="flex items-center text-lg text-gray-300 mb-4"><LocationIcon /> 123 Construction Ave, Metropolis, 10101</div>
                    <div className="flex items-center text-lg text-gray-300 mb-4"><PhoneIcon /> +1 (555) 123-4567</div>
                    <div className="flex items-center text-lg text-gray-300"><MailIcon /> contact@aluconstruct.pro</div>
                </div>
                <div>
                    <h3 className="text-2xl font-bold text-white mb-4">Payment Details</h3>
                     <div className="bg-slate-800 p-6 rounded-lg">
                        <p className="text-gray-400 mb-2"><strong>Bank:</strong> Metro Central Bank</p>
                        <p className="text-gray-400 mb-2"><strong>Account Name:</strong> AluConstruct Pro Inc.</p>
                        <p className="text-gray-400 mb-4"><strong>Account Number:</strong> 123-456-789012</p>
                        <p className="text-gray-300">We also accept major credit cards and wire transfers. Please mention your project ID in the payment reference.</p>
                    </div>
                </div>
            </div>
            {/* Right side: Form */}
            <div>
                 <h3 className="text-2xl font-bold text-white mb-4">Send Us a Message</h3>
                 <form className="space-y-4">
                     <div>
                         <label htmlFor="name" className="text-sm font-medium text-gray-300 block mb-1">Full Name</label>
                         <input type="text" id="name" name="name" className="w-full bg-slate-800 border border-slate-600 rounded-md py-2 px-3 text-white focus:outline-none focus:ring-2 focus:ring-cyan-500" placeholder="John Doe" />
                     </div>
                      <div>
                         <label htmlFor="email" className="text-sm font-medium text-gray-300 block mb-1">Email Address</label>
                         <input type="email" id="email" name="email" className="w-full bg-slate-800 border border-slate-600 rounded-md py-2 px-3 text-white focus:outline-none focus:ring-2 focus:ring-cyan-500" placeholder="you@example.com" />
                     </div>
                      <div>
                         <label htmlFor="message" className="text-sm font-medium text-gray-300 block mb-1">Message</label>
                         <textarea id="message" name="message" rows={5} className="w-full bg-slate-800 border border-slate-600 rounded-md py-2 px-3 text-white focus:outline-none focus:ring-2 focus:ring-cyan-500" placeholder="Tell us about your project..."></textarea>
                     </div>
                     <button type="submit" className="w-full px-8 py-3 bg-cyan-500 text-white font-bold text-lg rounded-lg hover:bg-cyan-400 focus:outline-none focus:ring-4 focus:ring-cyan-300 transition-all duration-300">
                        Submit Inquiry
                     </button>
                 </form>
            </div>
        </div>
    </Section>
);

const Footer = () => (
    <footer className="bg-slate-900 border-t border-slate-700 py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-gray-400">
            <p>&copy; {new Date().getFullYear()} AluConstruct Pro. All Rights Reserved.</p>
            <p className="text-sm mt-1">Designed with Precision and Care</p>
        </div>
    </footer>
);


// --- MAIN APP COMPONENT ---

const App: React.FC = () => {
    
  const scrollTo = (sectionId: string) => {
    const section = document.getElementById(sectionId);
    section?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };
    
  return (
    <div className="bg-slate-900 text-white">
      <Header scrollTo={scrollTo} />
      <main>
        <HeroSection scrollTo={scrollTo} />
        <GallerySection />
        <ServicesSection />
        <AboutSection />
        <ContactSection />
      </main>
      <Footer />
    </div>
  );
};

export default App;