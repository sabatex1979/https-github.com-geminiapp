
import React from 'react';
import Header from './components/Header';
import HeroSection from './components/HeroSection';
import KeyConceptsSection from './components/KeyConceptsSection';
import DataVisualizationSection from './components/DataVisualizationSection';
import AiEconomistSection from './components/AiEconomistSection';
import Footer from './components/Footer';

const App: React.FC = () => {
  return (
    <div className="bg-brand-dark min-h-screen text-brand-text font-sans antialiased">
      <Header />
      <main>
        <HeroSection />
        <KeyConceptsSection />
        <DataVisualizationSection />
        <AiEconomistSection />
      </main>
      <Footer />
    </div>
  );
};

export default App;
