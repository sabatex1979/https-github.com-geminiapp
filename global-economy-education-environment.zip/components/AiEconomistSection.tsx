
import React, { useState, useRef, useEffect } from 'react';
import type { ChatMessage } from '../types';
import { MessageSender } from '../types';
import { explainEconomicConcept } from '../services/geminiService';
import { AiIcon, SendIcon, UserIcon } from './IconComponents';

const AiEconomistSection: React.FC = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    { sender: MessageSender.AI, text: "Hello! I'm your AI Economics Tutor. Ask me to explain a concept, like 'inflation' or 'opportunity cost'." }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(scrollToBottom, [messages]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (input.trim() === '' || isLoading) return;

    const userMessage: ChatMessage = { sender: MessageSender.USER, text: input };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    const aiResponseText = await explainEconomicConcept(input);
    const aiMessage: ChatMessage = { sender: MessageSender.AI, text: aiResponseText };
    setMessages(prev => [...prev, aiMessage]);
    setIsLoading(false);
  };

  return (
    <section id="ai-tutor" className="py-16 md:py-24">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-brand-text">AI Economics Tutor</h2>
          <p className="mt-4 text-lg text-brand-text-secondary">
            Have a question? Get instant, easy-to-understand explanations from our AI expert.
          </p>
        </div>
        <div className="max-w-3xl mx-auto bg-brand-light-dark rounded-xl shadow-2xl flex flex-col" style={{height: '600px'}}>
          <div className="flex-1 p-4 sm:p-6 space-y-4 overflow-y-auto">
            {messages.map((msg, index) => (
              <div key={index} className={`flex items-start gap-3 ${msg.sender === MessageSender.USER ? 'justify-end' : 'justify-start'}`}>
                {msg.sender === MessageSender.AI && (
                  <div className="flex-shrink-0 w-8 h-8 rounded-full bg-brand-accent flex items-center justify-center">
                    <AiIcon />
                  </div>
                )}
                <div className={`max-w-md p-3 rounded-lg ${msg.sender === MessageSender.AI ? 'bg-slate-700' : 'bg-brand-accent'}`}>
                  <p className="text-sm text-white whitespace-pre-wrap">{msg.text}</p>
                </div>
                 {msg.sender === MessageSender.USER && (
                  <div className="flex-shrink-0 w-8 h-8 rounded-full bg-slate-600 flex items-center justify-center">
                    <UserIcon />
                  </div>
                )}
              </div>
            ))}
            {isLoading && (
               <div className="flex items-start gap-3 justify-start">
                   <div className="flex-shrink-0 w-8 h-8 rounded-full bg-brand-accent flex items-center justify-center">
                    <AiIcon />
                  </div>
                  <div className="max-w-md p-3 rounded-lg bg-slate-700 flex items-center space-x-2">
                      <span className="w-2 h-2 bg-white rounded-full animate-pulse-fast"></span>
                      <span className="w-2 h-2 bg-white rounded-full animate-pulse-fast" style={{animationDelay: '0.2s'}}></span>
                      <span className="w-2 h-2 bg-white rounded-full animate-pulse-fast" style={{animationDelay: '0.4s'}}></span>
                  </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>
          <div className="p-4 border-t border-slate-700">
            <form onSubmit={handleSendMessage} className="flex items-center gap-2">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="e.g., Explain 'quantitative easing'..."
                className="flex-1 bg-slate-700 text-brand-text rounded-full py-2 px-4 focus:outline-none focus:ring-2 focus:ring-brand-accent"
                disabled={isLoading}
              />
              <button
                type="submit"
                className="bg-brand-accent hover:bg-brand-accent-hover rounded-full p-2.5 text-white disabled:bg-slate-600 disabled:cursor-not-allowed transition-colors"
                disabled={isLoading}
              >
                <SendIcon />
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AiEconomistSection;
