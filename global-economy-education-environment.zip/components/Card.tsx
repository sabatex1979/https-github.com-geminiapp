
import React from 'react';
import type { EconomicConcept } from '../types';

interface CardProps {
  concept: EconomicConcept;
}

const Card: React.FC<CardProps> = ({ concept }) => {
  return (
    <div className="bg-brand-light-dark p-6 rounded-lg shadow-lg h-full flex flex-col border border-slate-700 hover:border-brand-accent hover:-translate-y-2 transition-all duration-300">
      <div className="flex-shrink-0 mb-4">
        <div className="w-12 h-12 rounded-full bg-brand-accent/20 text-brand-accent flex items-center justify-center">
            {concept.icon}
        </div>
      </div>
      <h3 className="text-xl font-bold text-brand-text mb-2">{concept.title}</h3>
      <p className="text-brand-text-secondary text-sm leading-relaxed flex-grow">
        {concept.description}
      </p>
    </div>
  );
};

export default Card;
