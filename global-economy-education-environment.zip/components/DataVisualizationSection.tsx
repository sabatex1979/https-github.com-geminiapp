
import React from 'react';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from 'recharts';
import { GDP_DATA } from '../constants';

const DataVisualizationSection: React.FC = () => {
  return (
    <section id="data" className="py-16 md:py-24 bg-brand-light-dark">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-brand-text">Global Economic Snapshot</h2>
          <p className="mt-4 text-lg text-brand-text-secondary">
            Visualize key economic indicators and trends across major economies.
          </p>
        </div>
        <div className="bg-brand-dark p-4 sm:p-6 md:p-8 rounded-xl shadow-2xl">
          <h3 className="text-xl font-semibold mb-6 text-brand-text">GDP of Major Economies (in Trillions USD)</h3>
          <div className="w-full h-72 md:h-96">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart
                data={GDP_DATA}
                margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
              >
                <defs>
                  <linearGradient id="colorUSA" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#8884d8" stopOpacity={0.8}/>
                    <stop offset="95%" stopColor="#8884d8" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorChina" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#82ca9d" stopOpacity={0.8}/>
                    <stop offset="95%" stopColor="#82ca9d" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorEU" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#ffc658" stopOpacity={0.8}/>
                    <stop offset="95%" stopColor="#ffc658" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis dataKey="year" stroke="#94a3b8" />
                <YAxis stroke="#94a3b8" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#1e293b',
                    borderColor: '#334155',
                    color: '#e2e8f0',
                  }}
                />
                <Legend wrapperStyle={{color: '#e2e8f0'}} />
                <Area type="monotone" dataKey="USA" stroke="#8884d8" fillOpacity={1} fill="url(#colorUSA)" />
                <Area type="monotone" dataKey="China" stroke="#82ca9d" fillOpacity={1} fill="url(#colorChina)" />
                <Area type="monotone" dataKey="EU" stroke="#ffc658" fillOpacity={1} fill="url(#colorEU)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
       <script src="https://unpkg.com/recharts/umd/Recharts.min.js"></script>
    </section>
  );
};

export default DataVisualizationSection;
