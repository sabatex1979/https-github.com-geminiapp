
import React from 'react';
import { LogoIcon } from './IconComponents';

const Footer: React.FC = () => {
  return (
    <footer className="bg-brand-light-dark border-t border-slate-800">
      <div className="container mx-auto py-8 px-4 sm:px-6 lg:px-8 text-center text-brand-text-secondary">
        <div className="flex justify-center items-center gap-2 mb-4">
          <LogoIcon />
          <span className="text-lg font-semibold text-brand-text">EconoSphere</span>
        </div>
        <p className="text-sm">
          &copy; {new Date().getFullYear()} EconoSphere. All Rights Reserved.
        </p>
        <p className="text-xs mt-2">
          An educational platform for exploring the global economy.
        </p>
      </div>
    </footer>
  );
};

export default Footer;
