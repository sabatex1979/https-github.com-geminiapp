
import React from 'react';

const HeroSection: React.FC = () => {
  return (
    <section id="hero" className="py-20 md:py-32 bg-brand-light-dark">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h1 className="text-4xl md:text-6xl font-extrabold text-brand-text tracking-tight animate-fade-in-up">
          Unlock the World of Economics
        </h1>
        <p className="mt-4 max-w-2xl mx-auto text-lg md:text-xl text-brand-text-secondary animate-fade-in-up" style={{ animationDelay: '0.2s' }}>
          Explore complex global economic concepts through interactive lessons, stunning data visualizations, and your own personal AI tutor.
        </p>
        <div className="mt-8 flex justify-center animate-fade-in-up" style={{ animationDelay: '0.4s' }}>
          <a
            href="#concepts"
            className="inline-block bg-brand-accent hover:bg-brand-accent-hover text-white font-bold py-3 px-8 rounded-full shadow-lg transform hover:-translate-y-1 transition-all duration-300"
          >
            Start Learning
          </a>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
