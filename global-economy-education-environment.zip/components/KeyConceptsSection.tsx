
import React from 'react';
import Card from './Card';
import { ECONOMIC_CONCEPTS } from '../constants';

const KeyConceptsSection: React.FC = () => {
  return (
    <section id="concepts" className="py-16 md:py-24">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-brand-text">Core Economic Concepts</h2>
          <p className="mt-4 text-lg text-brand-text-secondary">
            Grasp the fundamentals that drive the global economy.
          </p>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {ECONOMIC_CONCEPTS.map((concept, index) => (
             <div key={concept.title} className="animate-fade-in-up" style={{ animationDelay: `${index * 0.1}s` }}>
                <Card concept={concept} />
             </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default KeyConceptsSection;
