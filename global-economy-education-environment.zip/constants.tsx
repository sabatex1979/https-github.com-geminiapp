
import React from 'react';
import type { EconomicConcept, ChartData } from './types';
import { ScaleIcon, GlobeIcon, InflationIcon, BankIcon, GovIcon, BrainIcon } from './components/IconComponents';

export const ECONOMIC_CONCEPTS: EconomicConcept[] = [
  {
    icon: <ScaleIcon />,
    title: "Supply & Demand",
    description: "The fundamental model of price determination in a market. It postulates that, holding all else equal, in a competitive market, the unit price for a particular good will vary until it settles at a point where the quantity demanded equals the quantity supplied, resulting in an economic equilibrium.",
  },
  {
    icon: <GlobeIcon />,
    title: "GDP (Gross Domestic Product)",
    description: "The total monetary or market value of all the finished goods and services produced within a country's borders in a specific time period. It functions as a comprehensive scorecard of a given country’s economic health.",
  },
  {
    icon: <InflationIcon />,
    title: "Inflation",
    description: "The rate of increase in prices over a given period of time. Inflation is typically a broad measure, such as the overall increase in prices or the increase in the cost of living in a country.",
  },
  {
    icon: <GovIcon />,
    title: "Fiscal Policy",
    description: "The use of government spending and taxation to influence the economy. Governments typically use fiscal policy to promote strong and sustainable growth and reduce poverty.",
  },
  {
    icon: <BankIcon />,
    title: "Monetary Policy",
    description: "Policy adopted by the monetary authority of a nation to control either the interest rate payable for very short-term borrowing or the money supply, often as an attempt to reduce inflation or the interest rate to ensure price stability and general trust.",
  },
  {
    icon: <BrainIcon />,
    title: "Opportunity Cost",
    description: "Represents the potential benefits an individual, investor, or business misses out on when choosing one alternative over another. It's the value of the next-highest-valued alternative use of that resource.",
  },
];

export const GDP_DATA: ChartData[] = [
  { year: '2020', USA: 21.0, China: 14.7, EU: 15.3 },
  { year: '2021', USA: 23.3, China: 17.7, EU: 17.1 },
  { year: '2022', USA: 25.5, China: 18.1, EU: 16.6 },
  { year: '2023', USA: 27.4, China: 19.4, EU: 18.4 },
];
