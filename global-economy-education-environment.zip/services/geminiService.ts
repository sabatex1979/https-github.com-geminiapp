
import { GoogleGenAI } from "@google/genai";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  console.warn("API_KEY environment variable not set. AI features will not work.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY! });

export const explainEconomicConcept = async (topic: string): Promise<string> => {
  if (!API_KEY) {
    return "The AI Economist is currently unavailable. Please configure the API key.";
  }

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `Explain the economic concept of "${topic}" in a clear, concise, and easy-to-understand way for a beginner. Use an analogy if possible. Keep the response to about 3-4 paragraphs.`,
       config: {
        systemInstruction: "You are a friendly and knowledgeable economics professor who excels at simplifying complex topics for students.",
        temperature: 0.7,
        topP: 0.95,
      }
    });
    
    return response.text;

  } catch (error) {
    console.error("Error calling Gemini API:", error);
    return "I'm sorry, I encountered an error trying to process your request. Please try again later.";
  }
};
