
export interface EconomicConcept {
  icon: React.ReactNode;
  title: string;
  description: string;
}

export interface ChartData {
  year: string;
  USA: number;
  China: number;
  EU: number;
}

export enum MessageSender {
  USER = 'user',
  AI = 'ai',
}

export interface ChatMessage {
  sender: MessageSender;
  text: string;
}
